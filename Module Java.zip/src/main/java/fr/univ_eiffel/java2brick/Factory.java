package fr.univ_eiffel.java2brick;

public interface Factory {

}

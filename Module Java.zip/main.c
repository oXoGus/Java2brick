#include <assert.h>
#include <math.h>
#include <stdalign.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define NUM_BRICK_STRING_VALID_ARGS 7
#define UNPLACED -1; // identifiant d'une brique qui n'est pas placé

typedef struct Color {
  unsigned char red;   // les trois composantes de couleur
  unsigned char green; // en unsigned char et non pas en hexadecimal
  unsigned char blue;  // pour facilité le calcul de l'erreur
} Color;

typedef Color Pixel; // pour faciliter la compréhenion

typedef struct Brick {
  int id;              // l'identifiant de la brique
  int numBrickInStock; // le nombre de brique en stock
  int numBrickUsed; // le nombre de pièces posé sur un pavage (réinisitalisé à
                    // chaque nouveau pavage)
  int price;        // le prix en centime
  int *flattenedMatrix; // la matrice représentant la brique
  int height;           // hauteur de la brique
  int length;           // longeur de la brique
  Color color;          // la couleur de la brique
} Brick;

typedef struct Node {
  int index;  // l'index du node dans l'arbre
  int x;      // plus petit x parmis toutes les coordonnées x de ses nodes fils
  int y;      // plus petit y parmis toutes les coordonnées y de ses nodes fils
  int width;  // largeur de la briques (possible)
  int height; // hauteur de la brique (possible)
  Color avgColor; // la moyenne des couleurs des moyenne des couleurs de sous
                  // briques
  int brickId; // id de la brique 'placé sur le pavage' : -1 si la brique n'est
               // pas placé
  int isOutOfImage; // 1 si tout ses fils sont en dehors de l'image
} Node;

// structure de donnée avec tout les brick leur positions et leur orientations
// dans un quadtree
// le quadtree est sous forme de tableau de node
// ou chaque node pouvant représenter une brique carré (nécessairement puisque
// chaque carré doit pouvoir être divisé en 4 carré) on pourra avoir des briques
// rectangulaire en sortie mais il faudra faire une deuxième passe par un
// algoritmm de matching par exemple pour pouvoir fusionner les briques pour
// savoir si un node est une brique utilisé, chaque node dispose d'un champ
// brickId, si brickId = -1 c'est que ce node n'est pas une brique
typedef struct QuadTree {
  Node *nodes; // un node est null si il est situé en dehors de l'image
  int length;
  int depth;
} QuadTree;

typedef struct Paving {
  char *filePath;         // le nom du fichier ou le pavage est exporté
  int price;              // le prix du pavage
  int quality;            // la qualité du pavage
  int numBrickOutOfStock; // nombre de brick qui dont les stock sont épuisé, le
                          // nombre varie de 1 au nombre de Briques dans le
                          // fichier des stock
  Color *bricksPlacedColor; // tableau de toutes les couleurs des briques 1x1
                            // placé dans le pavage
  QuadTree data; // arbre représentant toutes les briques carré possible sur un
                 // pavage

} Paving;

typedef struct Image {
  int height;  // la hauteur de l'image
  int width;   // la largeur de l'image
  Pixel *data; // le matrice aplati contenant tout les Pixel de l'image
} Image;

// le quadtree est sous forme de tableau
// l'image doit déja rentrer dans un carré de dimension 4^n
// on peux retrouver le nombre de niveau de l'arbre
int getTreeLen(QuadTree *brickTree, Image *image) {

  // la plus grande des deux dim
  int largerDim;

  if (image->height >= image->width) {
    largerDim = image->height;
  } else {
    largerDim = image->width;
  }

  // on doit bien comparer tout les pixel a l'interieur du carré
  int imageSquareSize = largerDim * largerDim;

  // on test tout les puissance de 4
  int squareSize = 1;
  int numNodes = 1;
  int depth = 0;
  while (squareSize < imageSquareSize) {
    squareSize = squareSize * 4;
    numNodes += squareSize; // on compte tout les nodes
    depth++;
    // printf("%d\n", numNodes);
  }

  // on ajoute la profondeur de l'arbre
  brickTree->depth = depth;

  return numNodes;
}

// alloue la memoire pour le quadtree et initialise tout les node a null
QuadTree createBrickTree(Image *image) {

  QuadTree brickTree;

  // on ajoute la taille du tableau
  brickTree.length = getTreeLen(&brickTree, image);

  // on créer le tableau
  brickTree.nodes = (Node *)malloc(sizeof(Node) * brickTree.length);

  // par défaut tous les nodes sont en dehors de l'image
  for (int i = 0; i < brickTree.length; i++) {

    Node node;
    node.isOutOfImage = 1;
    node.index = i;
    node.brickId = -1; // pas de brick associé par défaut
    brickTree.nodes[i] = node;
  }

  return brickTree;
}

int getIndexFromCoords(QuadTree *brickTree, int x, int y, int tagetLayer) {

  // on peux voir ça comme de la dichotomie mais en deux dimension

  // on part du plus grand carré
  int xMin = 0;
  int xMax = pow(2, brickTree->depth);

  int yMin = 0;
  int yMax = pow(2, brickTree->depth);

  int nodeIndex = 0;

  // le node racine est forcément dans l'image
  brickTree->nodes[0].isOutOfImage = 0;

  // pour chaque layer
  for (int i = 0; i < brickTree->depth; i++) {

    // index du sous carré ou se trouve les coords
    int subIndex;

    // on cherche dans quel sous des 4 sous carré du layer se trouve les
    // coordonnes

    // on prends le milieu la longueur du côté en deux comme pour la dichotomie
    int xMid = (xMin + xMax) / 2;
    int yMid = (yMin + yMax) / 2;

    // on test si les coords sont dans le carré
    if (x >= xMid) {
      // deux carré de droites
      xMin = xMid;
      if (y < yMid) {
        subIndex = 2;
        yMax = yMid;
      } else {
        subIndex = 3;
        yMin = yMid;
      }
    }

    // deux carré de gauche
    else {

      xMax = xMid;

      if (y < yMid) {
        subIndex = 1;
        yMax = yMid;
      } else {
        subIndex = 4;
        yMin = yMid;
      }
    }

    nodeIndex = 4 * nodeIndex + subIndex;

    // si on arrive a cet index alors le node a cet index est dans l'image
    brickTree->nodes[nodeIndex].isOutOfImage = 0;
  }

  return nodeIndex;
}

Node *getLeafFromPixelPosition(QuadTree *brickTree, int x, int y) {
  // les feuilles sont au dernier niveau
  int leafIndex = getIndexFromCoords(brickTree, x, y, brickTree->depth);

  if (leafIndex > brickTree->length) {
    printf("Index %d out of bound for the coordinates (%d, %d)", leafIndex, x,
           y);
    exit(EXIT_FAILURE);
  }

  // printf("(%d, %d) = %d\n", x, y, leafIndex);

  // on retoune le pointeur du node a l'index
  return &brickTree->nodes[leafIndex];
}

// initialise un node représentant une brick de taille 1x1 en (x, y)
void initLeaf(QuadTree *brickTree, int x, int y, Brick brick) {

  // on récup la feuille de coordonnées x et y
  Node *leaf = getLeafFromPixelPosition(brickTree, x, y);

  // on initialise le node
  leaf->width = 1; // une feuille qui représente un pixel
  leaf->height = 1;
  leaf->brickId = brick.id;     // la brique est placé sur le pavage
  leaf->avgColor = brick.color; // pas de moyenne sur une seule couleur
  leaf->isOutOfImage = 0; // le node est dans l'image puisqu'on l'a trouvé a
                          // partir des coordonnées
  leaf->x = x;            // c'est ici qu'on initialise les coordonnées
  leaf->y = y;
}

int isBrickPlaced(Node node) {
  return node.brickId != -1 && node.isOutOfImage == 0;
}

// la taille maximal d'une ligne et le nombre de lignes
// revoie 1 si la file n'existe pas
int getFileDim(char *filePath, int *lineLen, int *numLine) {

  // on ouvre le fichier
  FILE *f;

  // en mode lecture
  f = fopen(filePath, "r");

  // si le fichier n'existe pas
  if (f == NULL) {
    return 1;
  }

  int maxLineLen = 0;
  int height = 0;

  // le caractère lu
  int c = 0;

  while (c != EOF) {
    int len = 0;

    // on incrémente la longeur de la ligne tant qu'on tombe pas sur '\n' ni
    // sur la fin du fichier
    while ((c = fgetc(f)) != '\n' && c != EOF) {
      len++;
    }

    // on compart avec la longeur de la ligne la plus grande
    if (len > maxLineLen) {
      maxLineLen = len;
    }

    if (c == EOF) {
      if (len > 0) {
        height++;
      }
      break;
    }
    height++;
  }

  *lineLen = maxLineLen;
  *numLine = height;

  fclose(f);

  return 0;
}

char **readLines(char *filePath, int lineLen, int numLine) {

  // on iniitalise la liste des lignes
  char **lines = malloc(sizeof(char *) * numLine);

  // on ouvre le fichier
  FILE *f;

  // en mode lecture
  f = fopen(filePath, "r");

  char line[lineLen + 2];
  int lineIndex = 0;

  // on récupère toute la ligne avec fgets
  while (fgets(line, lineLen + 2, f) != NULL && lineIndex < numLine) {
    // on marque la fin de la chaine
    line[lineLen] = '\0';

    lines[lineIndex] = malloc(strlen(line) + 1);
    strcpy(lines[lineIndex], line);

    lineIndex++;
  }

  // on oublie pas de fermer le fichier
  fclose(f);

  // on revoie la liste des lignes
  return lines;
}

Color hexToColor(char *hexString) {
  Color col;

  // on extrait les 2 bytes correspondant a la composante rouge
  char redComponent[3];
  strncpy(redComponent, hexString, 2);
  redComponent[2] = '\0';
  col.red = (int)strtol(redComponent, NULL, 16);

  // même chose pour la composante verte
  char greenComponent[3];
  strncpy(greenComponent, hexString + 2, 2);
  greenComponent[2] = '\0';
  col.green = (int)strtol(greenComponent, NULL, 16);

  // et pour la composante bleu
  char blueComponent[3];
  strncpy(blueComponent, hexString + 4, 2);
  blueComponent[2] = '\0';
  col.blue = (int)strtol(blueComponent, NULL, 16);

  return col;
}

void printColor(Color col) {
  printf("(%d, %d, %d)\n", col.red, col.green, col.blue);
}

// renvoie 1 si le split de la string contient bien toutes les informations
// nécessaire
int isBrickStringValid(char *brickString) {

  // on doit utiliser un copie de la chaine puisque strtok la modifie

  char *brickStringCopy = malloc(sizeof(char) * strlen(brickString) + 1);
  strncpy(brickStringCopy, brickString, strlen(brickString));
  brickStringCopy[strlen(brickString)] = '\0';

  // on split la chaine de caractère
  char *token = strtok(brickStringCopy, " ");

  int c = 0;
  while (token != NULL) {
    c++;
    token = strtok(NULL, " ");
  }

  free(brickStringCopy);

  return c == NUM_BRICK_STRING_VALID_ARGS;
}

int getFlattenedMatrix(Brick brick, int i, int j) {
  return brick.flattenedMatrix[i * brick.length + j];
}

void printBrickMatrix(Brick brick) {
  for (int i = 0; i < brick.height; i++) {
    for (int j = 0; j < brick.length; j++) {
      if (j == brick.length - 1) {
        printf("%d", getFlattenedMatrix(brick, i, j));
      } else {
        printf("%d, ", getFlattenedMatrix(brick, i, j));
      }
    }
    printf("\n");
  }
}

int *parseBrickMatrix(char *matrixString, int height, int length) {

  int *flattenedMatrix = (int *)malloc(sizeof(int) * (height * length));

  // on 'parcours' la string et on convertit chaque caractère en int
  for (int i = 0; i < height * length; i++) {
    char digit[2];

    strncpy(digit, matrixString + i, 1);

    digit[1] = '\0';

    sscanf(digit, "%d", &flattenedMatrix[i]);
  }

  return flattenedMatrix;
}

void printBrick(Brick brick) {
  printf("id : %d\n", brick.id);
  printf("color : ");
  printColor(brick.color);
  printf("height : %d\n", brick.height);
  printf("length : %d\n", brick.length);
  printf("matrix : \n");
  printBrickMatrix(brick);
  printf("price : %lf€\n", (double)brick.price / 100);
  printf("pieces in stock : %d\n", brick.numBrickInStock);
}

Brick parseBrick(char *brickString) {

  // on verifie d'abord si la string est valide
  if (isBrickStringValid(brickString) == 0) {
    printf("The string '%s' is not valid", brickString);
    exit(EXIT_FAILURE);
  }

  // on initialise la brique
  Brick brick;

  // on split la chaine de caractère
  char *token = strtok(brickString, " ");

  // on extrait toutes les informations concernant la brique
  sscanf(token, "%d", &brick.id);

  // on récupère la prochaine chaine entre des espaces
  token = strtok(NULL, " ");

  char hexString[7];
  strncpy(hexString, token, 6);
  hexString[6] = '\0';

  brick.color = hexToColor(hexString);

  token = strtok(NULL, " ");

  // les dimensions de la brique
  sscanf(token, "%d", &brick.height);

  token = strtok(NULL, " ");

  sscanf(token, "%d", &brick.length);

  token = strtok(NULL, " ");

  // matrice aplati représentant la brique
  // on verifie que les dimensions sont bonnes
  if (strlen(token) != (unsigned long)brick.height * brick.length) {
    printf("The matrix '%s' doesn't correspond to the dimensions %dx%d", token,
           brick.height, brick.length);
    exit(EXIT_FAILURE);
  }

  brick.flattenedMatrix = parseBrickMatrix(token, brick.height, brick.length);

  // le prix de la brique en centime
  token = strtok(NULL, " ");

  sscanf(token, "%d", &brick.price);

  // le nombre de pieces en stockes
  token = strtok(NULL, " ");

  sscanf(token, "%d", &brick.numBrickInStock);

  // valeurs par défaut
  brick.numBrickUsed = 0;

  return brick;
}

// function de récuperations des briques
// on renvoie le nombre de briques
// on prends en paramètre le pointeur d'un tableau
int getBrickList(char *filePath, Brick **brickList) {

  // on récupère les dimensions des lignes et le nombre de ligne
  int lineLen = -1;
  int numLine = -1;

  if (getFileDim(filePath, &lineLen, &numLine)) {
    // la file n'existe pas
    return -1;
  }

  // on recupère les liges du fichier
  char **lines = readLines(filePath, lineLen, numLine);

  // le premier élément de la liste est une chaine vide
  for (int i = 0; i < numLine; i++) {
    (*brickList)[i] = parseBrick(lines[i]);
  }

  return numLine;
}

void verifyImageFormat(char **lines, int numLine) {
  // toutes les lignes doivent faire la meme taille
  int initLenLine = strlen(lines[0]);
  // printf("%d\n", initLenLine);
  for (int i = 0; i < numLine; i++) {
    int lenLine = strlen(lines[i]);

    if (lenLine != initLenLine) {
      printf("The line %d has has to less or to much pixels", i + 1);
      exit(EXIT_FAILURE);
    }
  }
}

int getNumPixelInOneLine(char *line) {
  // copie la chaine puisque la fonction strtok la modifie
  char *lineCopy = malloc(sizeof(char) * strlen(line) + 1);
  strcpy(lineCopy, line);

  char *token = strtok(lineCopy, " ");
  int pixelCount = 0;
  while (token != NULL) {
    pixelCount++;
    token = strtok(NULL, " ");
  }

  return pixelCount;
}

int getImageWidth(char **lines, int numLine) {
  // on a verifié le si toutes les lignes était de même taille
  verifyImageFormat(lines, numLine);

  // mais deux lignes peuvent avoir un nombre de pixel différent tout en ayant
  // la même longeur
  int numPixel = getNumPixelInOneLine(lines[0]);

  for (int i = 0; i < numLine; i++) {
    if (getNumPixelInOneLine(lines[i]) != numPixel) {
      printf("The pixel line %d is not formated correctly", i + 1);
      exit(EXIT_FAILURE);
    }
  }

  return numPixel;
}

void parsePixelLine(Image *image, char *line, int numLine) {
  char *hexString = strtok(line, " ");
  int numPixel = 0;
  while (hexString != NULL) {
    image->data[numLine * image->width + numPixel] = hexToColor(hexString);

    numPixel++;

    // on récupère la prochaine hexString
    hexString = strtok(NULL, " ");
  }
}

Pixel getPixel(Image image, int i, int j) {
  return image.data[i * image.width + j];
}

void printImage(Image image) {
  for (int i = 0; i < image.height; i++) {
    for (int j = 0; j < image.width; j++) {
      Pixel pixel = getPixel(image, i, j);
      printf("(%d, %d, %d) ", pixel.red, pixel.green, pixel.blue);
    }
    printf("\n");
  }
}

void parseImage(Image *image, char **lines) {
  // on créer la matrice aplati des pixels de l'image
  image->data = (Pixel *)malloc(sizeof(Pixel) * (image->width * image->height));

  for (int i = 0; i < image->height; i++) {
    parsePixelLine(image, lines[i], i);
  }
}

Image getImage(char *filePath) {

  // on récupère les dimensions des lignes et le nombre de ligne
  int lineLen = -1;
  int numLine = -1;

  if (getFileDim(filePath, &lineLen, &numLine) == 1) {
    // la file n'existe pas
    printf("The file '%s' doesn't exist", filePath);
    exit(EXIT_FAILURE);
  }

  // on initialise l'image
  Image image;

  image.height = numLine;

  // on recupère les liges du fichier
  char **lines = readLines(filePath, lineLen, numLine);

  // on calcul la largeur de l'image en pixel
  image.width = getImageWidth(lines, numLine);

  parseImage(&image, lines);

  return image;
}

int isCoordInsideImage(int x, int y, Image *image) {
  return x >= 0 && x > image->width && y >= 0 && y < image->height;
}

void getCoord(int u, Image *image, int *x, int *y) {
  *x = (int)u % image->width;
  *y = (int)u / image->width;
}

int calculateColorError(Pixel pixel, Brick brick) {
  Color brickColor = brick.color;
  return pow(pixel.red - brickColor.red, 2) +
         pow(pixel.green - brickColor.green, 2) +
         pow(pixel.blue - brickColor.blue, 2);
}

int isBrickInStock(Brick brick) {
  return brick.numBrickInStock - brick.numBrickUsed > 0;
}

int numNodeInImage(QuadTree *brickTree) {
  int c = 0;
  for (int i = 0; i < brickTree->length; i++) {
    if (brickTree->nodes[i].brickId != -1) {
      c++;
    }
  }
  return c;
}

int isBrick1x1(Brick brick) { return brick.height == 1 && brick.length == 1; }

// place la meilleur brique 1x1 en fonction des stock et de sa couleur
void placeBrickBestColor(Paving *paving, Brick **brickList, int numBrick,
                         Pixel pixel, int posI, int posJ) {

  int minColorError = -1;
  int bestBrickId;
  int bestBrickIndex;

  // on prends la premiere brique en stock comme brique par défaut pour avoir
  // une base a comparer
  for (int i = 0; i < numBrick; i++) {
    Brick brick = (*brickList)[i];
    if (isBrickInStock(brick) == 1 && isBrick1x1(brick) == 1) {
      minColorError = calculateColorError(pixel, brick);
      bestBrickId = brick.id;
      bestBrickIndex = i;
      break;
    }
  }

  // si il n'y a plus de briques en stock
  if (minColorError == -1) {
    printf("There is no more brick in stock");
    exit(EXIT_FAILURE);
  }

  // pour chaque brique
  for (int i = 0; i < numBrick; i++) {

    Brick brick = (*brickList)[i];

    // la brique doit être en stock
    if (isBrickInStock(brick) && isBrick1x1(brick)) {
      // on calcul l'erreur de couleur
      int colorError = calculateColorError(pixel, brick);

      // on cherche la brique d'erreur de couleur minimal
      if (colorError < minColorError) {
        minColorError = colorError;
        bestBrickId = brick.id;
        bestBrickIndex = i;
      }
    }
  }

  // initialise la feuille de l'arbre qui a les coordonnées x et y sur l'image
  initLeaf(&(paving->data), posJ, posI, (*brickList)[bestBrickIndex]);

  // on met a jour le stock
  (*brickList)[bestBrickIndex].numBrickUsed++;

  // si on viens de placer la derniere brique du stock
  if (isBrickInStock((*brickList)[bestBrickIndex]) != 1) {
    paving->numBrickOutOfStock++;
  }

  // on incrémente le prix
  paving->price += (*brickList)[bestBrickIndex].price;

  // on met a jour la qualité du pavage
  paving->quality += minColorError;
}

void exportPaving(char *filePath, Paving paving) {
  FILE *f;
  // on ouvre le fichier en mode écriture
  f = fopen(filePath, "w");

  if (f == NULL) {
    printf("the file : '%s' doesn\'t exist", filePath);
    exit(EXIT_FAILURE);
  }

  // on parcours le tableau de nodes
  // l'ordre n'importe pas
  // bien qu'on pourrai parcourir l'arbre depuis la racine et dès qu'une brique
  // est posé sur le pavage on ne regarde pas tout les fils de ce node
  int nodeIndex = 0;

  for (int nodeIndex = 0; nodeIndex < paving.data.length; nodeIndex++) {

    // on récup le node
    Node node = paving.data.nodes[nodeIndex];

    // si la brique est placé dans le pavage
    if (isBrickPlaced(node) == 1) {
      // direction est toujour 1 puique le quadtree permet d'utiliser uniquement
      // des brique carré
      fprintf(f, "%d %d %d 1\n", node.brickId, node.x, node.y);
    }
  }

  fclose(f);
}

int isSameColor(Node *node1, Node *node2) {
  return node1->avgColor.blue == node2->avgColor.blue &&
         node1->avgColor.green == node2->avgColor.green &&
         node1->avgColor.red == node2->avgColor.red;
}

int isSameCol(Color col1, Color col2) {
  return col1.blue == col2.blue && col1.green == col2.green &&
         col1.red == col2.red;
}

// renvoie 1 et associe la brick trouvé si elle existe et est en stock
int findBrick(Brick **brickList, Color color, int width, int height,
              Brick *brickFound, int numBrick) {
  for (int i = 0; i < numBrick; i++) {
    Brick brick = (*brickList)[i];

    if (isSameCol(color, brick.color) == 1 && brick.height == height &&
        brick.length == width && isBrickInStock(brick)) {

      *brickFound = brick;
      return 1;
    }
  }

  // pas de brick trouvé
  return 0;
}

int isAllSameColor(Node *son1, Node *son2, Node *son3, Node *son4) {
  return isSameColor(son1, son2) && isSameColor(son2, son3) &&
         isSameColor(son3, son4);
}

int isNodeOutOfImage(Node *node) { return node->isOutOfImage; }

// revoie 1 si les 4 nodes fils doivent merge et 0 sinon
// si les 4 nodes fils doivent merge on assigne la brick avec qu'on doit
// utiliser après le merge
int isBricksMergeable(Node *son1, Node *son2, Node *son3, Node *son4,
                      Brick *brickChosen, Brick **brickList, int numBrick) {

  // on ne peux pas merge des brick qui sont en dehors de l'image
  if (isNodeOutOfImage(son1) == 1 || isNodeOutOfImage(son2) == 1 ||
      isNodeOutOfImage(son3) == 1 || isNodeOutOfImage(son4) == 1) {
    return 0;
  }

  // les 4 fils peuvent merge uniquement si leur couleur  sont les meme
  if (isAllSameColor(son1, son2, son3, son4) == 0) {
    return 0; // on ne peux pas merge les brick
  }
  // les dimensions de la nouvelle brick
  int newHeight = son1->height * 2;
  int newWidth = son1->width * 2;

  // on recherche si il existe dans la liste des brick
  // et en stock
  return findBrick(brickList, son1->avgColor, newWidth, newHeight, brickChosen,
                   numBrick);
}

int isNodeLeaf(Node *node) {

  // on consière toutes les nodes en dehors de l'image
  // comme des feuilles pour ne pas appeler ses fils à l'infinis
  // dans mergeBrickRec
  return node->height == 1 || node->isOutOfImage == 1;
}

// fusionne les 4 nodes fils dans le parent
void mergeSons(Node *parent, Node *son1, Node *son2, Node *son3, Node *son4,
               Brick brickChosen, Brick **brickList, int brickNum) {

  // on update les info du parent

  // puisqu'on fusionne uniquement si les brick on sont de meme couloeur pas
  // besoin de faire de moyenne
  parent->avgColor = son1->avgColor;

  // coordonnées en haut a gauche
  parent->x = son1->x;
  parent->y = son1->y;

  // les dimensions
  parent->height = son1->height * 2;
  parent->width = son2->width * 2;

  // l'id de la brick dans la liste des brick
  parent->brickId = brickChosen.id;

  // on update maintenant les info des fils
  // on retire leur brick
  son1->brickId = -1;
  son2->brickId = -1;
  son3->brickId = -1;
  son4->brickId = -1;

  // on update le stock
  // comme toutes les nodes fils ont la même brick
  // on prends juste la brick du premier
  for (int i = 0; i < brickNum; i++) {
    Brick *brick = &((*brickList)[i]);

    if (brick->id == son1->brickId) {
      brick->numBrickInStock += 4; // remet les 4 brick fils en stock
      return;
    }
  }
}

// fusionne toutes les brick possible récursivement
Node *mergeBrickRec(QuadTree *brickTree, int nodeIndex, Brick **brickList,
                    int numBrick) {

  if (nodeIndex > brickTree->length) {
    printf("%d\n", nodeIndex);
  }
  // on récup le node a l'index
  Node *parentNode = &(brickTree->nodes[nodeIndex]);

  // si le node est une feuille
  if (isNodeLeaf(parentNode) == 1) {

    // on revoie le fils pour que sont père puisse merge ou pas selon les
    // couleur de ses fils
    return parentNode;
  }

  // si le node est un parent

  // on récup les ses 4 fils
  Node *son1 = mergeBrickRec(brickTree, 4 * nodeIndex + 1, brickList, numBrick);
  Node *son2 = mergeBrickRec(brickTree, 4 * nodeIndex + 2, brickList, numBrick);
  Node *son3 = mergeBrickRec(brickTree, 4 * nodeIndex + 3, brickList, numBrick);
  Node *son4 = mergeBrickRec(brickTree, 4 * nodeIndex + 4, brickList, numBrick);

  // brick séléctionné si pour remplacer les 4 fils
  Brick brickChosen;

  // si on peux bien merge les 4 fils

  if (isBricksMergeable(son1, son2, son3, son4, &brickChosen, brickList,
                        numBrick) == 1) {

    mergeSons(parentNode, son1, son2, son3, son4, brickChosen, brickList,
              numBrick);
  }

  // on return le parent qui sera traité comme un enfant
  return parentNode;
}

void mergeBrick(QuadTree *brickTree, Brick **brickList, int numBrick) {

  // on appel la fonction récusive a partir du node racine
  mergeBrickRec(brickTree, 0, brickList, numBrick);
}

Paving makePavingBestColor(Brick *brickList, int numBrick, Image image,
                           char *fileToExportPath) {

  // on iniitalise le pavage
  Paving paving;
  paving.data = createBrickTree(&image);
  paving.filePath = fileToExportPath;
  paving.numBrickOutOfStock = 0;
  paving.price = 0;
  paving.quality = 0;

  paving.bricksPlacedColor =
      (Color *)malloc(sizeof(Color) * image.width * image.height);

  int numPixel = image.width * image.height;

  // premier pavage avec uniqument des briques 1x1
  int c = 0;
  // pour chaque pixel de l'image
  for (int i = 0; i < image.height; i++) {
    for (int j = 0; j < image.width; j++) {
      // on place la brique qui a la couleur qui se rapproche le plus du pixel
      placeBrickBestColor(&paving, &brickList, numBrick, getPixel(image, i, j),
                          i, j);
    }
    // on affiche pas la progression a chaque pixel pour ne pas surcharger
    // l'affichage
    printf("Creating your LEGO... %.2f%%\n",
           ((double)((i + 1) * image.width) / numPixel) * 100);
  }

  // affichage repris dans le java qui est ensuite repris dans le PHP pour être
  // afficher à l'utilisateur en temps réel
  printf("Reducing the number of brick used...\n");

  int brickNumBefore = numNodeInImage(&(paving.data));

  // une fois qu'on a initialisé toutes les feuilles a l'interieur de notre
  // image on remonte tout les niveau de notre arbre en essayant de
  // fusionner les brick
  mergeBrick(&(paving.data), &brickList, numBrick);

  printf("Merged %d bricks\n", brickNumBefore - numNodeInImage(&(paving.data)));

  printf("Exporting your LEGO\n");

  // on exporte le pavage dans le fichier passé en argument
  exportPaving(fileToExportPath, paving);
  return paving;
}

int main(int argc, char **argv) {
  // le argv[1] => fichier contenant les stock de briques
  // si les fichiers sont bien été mis en paramètre
  // au moins un fichier des stockes
  // et un fichier contenant l'image à paver
  // et un fichier ou exporter le 1er pavage

  if (argc < 4) {
    printf("This program need at least to have these files : [stock file] "
           "[image] [file to export the first paving] ");
    return 1;
  }

  char *fileStockPath = argv[1];

  int numBrick = 0;
  int lineLen = 0;

  // on récup le nombre de briques
  if (getFileDim(fileStockPath, &lineLen, &numBrick)) {
    printf("the file : '%s' doesn\'t exist", fileStockPath);
    exit(EXIT_FAILURE);
  }

  Brick *brickList = malloc(sizeof(Brick) * numBrick);

  printf("Checking the brick stock...\n");

  getBrickList(fileStockPath, &brickList);

  char *fileImagePath = argv[2];

  printf("Reading your image...\n");

  // on parse l'image à partir du fichier texte
  Image image = getImage(fileImagePath);

  char *filePaving1Path = argv[3];
  // premier pavage basé sur la meilleur ressemblance des couleurs
  Paving pavingBestColor =
      makePavingBestColor(brickList, numBrick, image, filePaving1Path);

  printf("Your LEGO has been created!\n");

  // on part du principe que la sortie standard est le terminal
  // on fait bien la comvertion en euro pour le prix

  // on affiche pas cette ligne aux utilisateurs
  /*
    printf("%s %.2lf %d %d\n", pavingBestColor.filePath,
         (double)pavingBestColor.price / 100, pavingBestColor.quality,
         pavingBestColor.numBrickOutOfStock);
    */
  return 0;
}
